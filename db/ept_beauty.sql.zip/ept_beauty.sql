-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 04, 2022 at 05:38 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ept_beauty`
--
CREATE DATABASE IF NOT EXISTS `ept_beauty` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `ept_beauty`;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
CREATE TABLE IF NOT EXISTS `carts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES
(1, 'Make up', '2022-09-07 06:37:42'),
(2, 'Skincare', '2022-09-07 06:40:29');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `status` enum('wait','confirmed') COLLATE utf8_bin NOT NULL DEFAULT 'wait',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `status`, `created_at`) VALUES
(1, 16, 'wait', '2022-09-15 16:56:55'),
(2, 16, 'confirmed', '2022-09-15 17:12:38'),
(3, 16, 'wait', '2022-09-15 17:30:04'),
(4, 16, 'wait', '2022-09-29 15:04:27'),
(5, 16, 'wait', '2022-09-29 15:05:59'),
(6, 16, 'wait', '2022-10-04 14:53:34'),
(7, 16, 'wait', '2022-10-04 14:59:59');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

DROP TABLE IF EXISTS `order_detail`;
CREATE TABLE IF NOT EXISTS `order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `price` double NOT NULL DEFAULT 0,
  `discount` int(11) NOT NULL DEFAULT 0,
  `qty` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `product_id`, `order_id`, `price`, `discount`, `qty`, `created_at`) VALUES
(1, 11, 1, 1200, 0, 1, '2022-09-15 16:56:55'),
(2, 8, 1, 2500, 5, 3, '2022-09-15 16:56:55'),
(3, 9, 1, 4500, 10, 3, '2022-09-15 16:56:55'),
(4, 10, 1, 1500, 0, 1, '2022-09-15 16:56:55'),
(5, 9, 2, 4500, 10, 1, '2022-09-15 17:12:38'),
(6, 8, 2, 2500, 5, 1, '2022-09-15 17:12:38'),
(7, 7, 2, 2400, 10, 1, '2022-09-15 17:12:38'),
(8, 8, 3, 2500, 5, 1, '2022-09-15 17:30:04'),
(9, 7, 3, 2400, 10, 1, '2022-09-15 17:30:04'),
(10, 10, 3, 1500, 0, 1, '2022-08-15 17:30:04'),
(11, 16, 4, 1450, 0, 5, '2022-09-29 15:04:27'),
(12, 15, 4, 1500, 5, 6, '2022-09-29 15:04:27'),
(13, 14, 4, 1230, 0, 8, '2022-09-29 15:04:27'),
(14, 8, 4, 2500, 5, 4, '2022-09-29 15:04:27'),
(15, 7, 4, 2400, 10, 3, '2022-09-29 15:04:27'),
(16, 16, 5, 1450, 0, 1, '2022-09-29 15:05:59'),
(17, 14, 7, 1230, 0, 1, '2022-10-04 14:59:59'),
(18, 7, 7, 2400, 10, 1, '2022-10-04 14:59:59'),
(19, 8, 7, 2500, 5, 2, '2022-10-04 14:59:59');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `path_img` text COLLATE utf8_bin NOT NULL,
  `price` double NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_bin DEFAULT NULL,
  `discount` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `path_img`, `price`, `description`, `discount`, `stock`, `is_active`, `created_at`) VALUES
(6, 1, 'Cream', 'back_end/images/6319ee6c2803b_2A12FC91-6C42-4EB1-8493-62662B55A982_4_5005_c.jpeg', 12, 'fffff', 12, 12, 0, '2022-09-08 13:30:20'),
(5, 1, 'bobbie', 'back_end/images/6319b64d0ba16_2A12FC91-6C42-4EB1-8493-62662B55A982_4_5005_c.jpeg', 2599, 'red', 10, 10, 0, '2022-09-08 09:30:53'),
(4, 1, 'bobbie2', 'back_end/images/631a047b338d0_2B26F852-24B7-4377-8E8F-A3D2FB22C530_4_5005_c.jpeg', 2566, 'wwww', 22, 40, 0, '2022-09-08 09:30:41'),
(7, 2, 'Hydrating Water Fresh Cream 50 ml.', 'back_end/images/631c93a623e1f_HydratingWaterFreshCream.jpeg', 2400, 'This lightweight cream delivers 100 hours of nonstop hydration.', 10, 20, 1, '2022-09-10 13:39:50'),
(8, 2, 'Vitamin Enriched Face Base 50 ml.', 'back_end/images/631c94b8d5d47_VitaminC.jpeg', 2500, 'A blend of Vitamins B, C, and E helps replenish.', 5, 30, 1, '2022-09-10 13:44:24'),
(9, 2, 'Extra Repair Serum100 ml.', 'back_end/images/631c953347d9e_EXTRA REPAIR SERUM.webp', 4500, 'Bobbi\'s solution for dry or very dry skin. ', 10, 20, 1, '2022-09-10 13:46:27'),
(10, 2, 'Instant Long-Wear Makeup Remover 100 ml.', 'back_end/images/631c95a3a7b02_Intant Long Wear Makeup Remove.webp', 1500, 'Makeup Remover.', 0, 35, 1, '2022-09-10 13:48:19'),
(11, 1, 'Primer Plus Mattifier 30 ml.', 'back_end/images/631c960d3f1d7_Primer Plus Mattifiet.webp', 1200, 'Face Primer', 0, 0, 1, '2022-09-10 13:50:05'),
(12, 2, 'Soothing Cleansing Oil 200 ml.', 'back_end/images/631c964ca3be7_Soothing Cleansing Oil.webp', 1100, 'Cleaning Oil.', 0, 15, 1, '2022-09-10 13:51:08'),
(13, 2, 'Extra Repair Eye Cream Intense 15 ml.', 'back_end/images/631c9a1399d79_Extra Repair Eye Cream Intense 15 ml.jpeg', 3500, 'Helps replenish, brighten, depuff, and reduce the look of dark circles.', 20, 10, 1, '2022-09-10 14:07:15'),
(14, 1, 'Luxe Eye Shadow.', 'back_end/images/631c9a97b8a80_Luxe Eye Shadow.jpeg', 1230, 'Creates a high-impact, multidimensional, and radiant finish.', 0, 25, 1, '2022-09-10 14:09:27'),
(15, 1, 'Luxe Illuminating Limited Edition Duo Pink.', 'back_end/images/631c9ad86b5a7_Luxe Illuminating Limited Edition Duo Pink.jpeg', 1500, 'Pressed powder highlighter duo.', 5, 30, 1, '2022-09-10 14:10:32'),
(16, 1, 'Brow Kit Dark 1 oz', 'back_end/images/631c9c2860cbc_Brow Kit Dark 1 oz.jpeg', 1450, 'Each tin is packed with two brow powder shades.', 0, 20, 1, '2022-09-10 14:11:50'),
(17, 1, 'Precise Blending Brush.', 'back_end/images/631c9b62058f3_Precise Blending Brush.jpeg', 1100, 'A curved brush designed to hug the contours of your face for effortless application of highlighting powders.', 5, 20, 1, '2022-08-10 14:12:50'),
(18, 1, 'Smooth Blending Brush.', 'back_end/images/631c9b933d98e_Smooth Blending Brush.jpeg', 1200, 'The Soft Blending Eyeshadow Brush.', 5, 10, 1, '2022-08-10 14:13:39'),
(19, 1, 'Eye Shadow Palette.', 'back_end/images/631c9bd09efc9_Eye Shadow Palette Stonewashed Nudes 8.5 g.jpg', 1200, 'Stonewashed Nudes Eye shadow palette 8.5 g.', 5, 20, 1, '2022-08-10 14:14:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `surname` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `password` text COLLATE utf8_bin NOT NULL,
  `district` varchar(50) COLLATE utf8_bin NOT NULL,
  `sub_district` varchar(50) COLLATE utf8_bin NOT NULL,
  `zip_code` varchar(5) COLLATE utf8_bin NOT NULL,
  `address` text COLLATE utf8_bin NOT NULL,
  `credit` double NOT NULL DEFAULT 0,
  `role` enum('admin','customer') COLLATE utf8_bin NOT NULL DEFAULT 'customer',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `email`, `password`, `district`, `sub_district`, `zip_code`, `address`, `credit`, `role`, `created_at`) VALUES
(16, 'Peearpar Phusitsawat', 'Ta', 'phusit_sawat7@hotmail.com', '8d73686229756822e4bd7f0d6e2adc38', 'aaa', 'bbbb', '11111', '30 Bangbon3Soi12 Laksong Bangkea', 112195, 'customer', '2022-09-06 11:06:17'),
(17, 'SuperAdmin', 'Admin', 'admin@gmail.com', '048d2b6e8795632ba63db1a0732b61d7', 'aaa', 'bbb', '10160', '30 Bangbon3Soi12 Laksong Bangkea', 40000, 'admin', '2022-09-06 13:36:28');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
